﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizEnem
{
    internal class Class1
    {
        public static int acertos = 0;
        public static bool questao1 = false;
        public static bool questao2 = false;
        public static bool questao3 = false;
        public static bool questao4 = false;
        public static bool questao5 = false;
        public static bool questao6 = false;
        public static bool questao7 = false;
        public static bool questao8 = false;
        public static bool questao9 = false;
        public static bool questao10 = false;
    }
}
