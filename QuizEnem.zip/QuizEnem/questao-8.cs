﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class questao_8 : Form
    {
        public questao_8()
        {
            InitializeComponent();
        }
    }
}
